### Entrega M4 - CRUD de produto

Ao clonar, rode o comando `npm install` para instalar as dependências

Você poderá iniciar a aplicação rodando o comando:

```
npm run dev
```

Você poderá rodar os testes automáticos preparádos para essa aplicação rodando o comando:

```
npm run test
```